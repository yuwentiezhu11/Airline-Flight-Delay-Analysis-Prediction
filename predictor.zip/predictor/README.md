# Airline Flight Delay Predictor 

## Step 1 Start the python-flask backend

```bash
cd predictor
python server.py
```

## Step 2 Start the React frontend

Install the necessary packages

```bash
cd client
npm install
```

Start the frontend

```bash
npm run start
```

## Step 3 Open the browser

Visit [localhost:3000](localhost:3000)

