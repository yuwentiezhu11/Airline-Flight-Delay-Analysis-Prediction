import React, { useState, useEffect } from 'react';
import Select from "react-tailwindcss-select";
import Swal from 'sweetalert2'

function App() {

	// const [parameters, setParameters] = useState([{}]);
	const [predictval, setPredictval] = useState("")
	const [parameter1, setParameter1] = useState("");
	const [parameter2, setParameter2] = useState("");
	const [parameter3, setParameter3] = useState("");
	const [parameter4, setParameter4] = useState("");
	const [parameter5, setParameter5] = useState("");
	const [parameter6, setParameter6] = useState("");

	const options1 = [
		{ value: "WN(Southwest Airlines)", label: "WN(Southwest Airlines)" },
		{ value: "DL(Delta Airlines)", label: "DL(Delta Airlines)" },
		{ value: "OO(Skywest Airlines)", label: "OO(Skywest Airlines)" },
		{ value: "AA(American Airlines)", label: "AA(American Airlines)" },
		{ value: "MQ(Envoy Air)", label: "MQ(Envoy Air)" },
		{ value: "US(US Airways)", label: "US(US Airways)" },
		{ value: "XE(JSX)", label: "XE(JSX)" },
		{ value: "EV(ExpressJet)", label: "EV(ExpressJet)" },
		{ value: "UA(United Airlines)", label: "UA(United Airlines)" },
		{ value: "CO(Continental Airlines)", label: "CO(Continental Airlines)" },
		{ value: "FL(Airtran Airways)", label: "FL(Airtran Airways)" },
		{ value: "9E(Endeavor Air)", label: "9E(Endeavor Air)" },
		{ value: "B6(JetBlue)", label: "B6(JetBlue)" },
		{ value: "YV(Mesa Airlines)", label: "YV(Mesa Airlines)" },
		{ value: "OH(PSA Airlines)", label: "OH(PSA Airlines)" },
		{ value: "AS(Alaska Airlines)", label: "AS(Alaska Airlines)" },
		{ value: "F9(Frontier Airlines)", label: "F9(Frontier Airlines)" },
		{ value: "HA(Hawaiian Airlines)", label: "HA(Hawaiian Airlines)" },
	];

	const options2 = [
		{ value: "ABE", label: "ABE" },
		{ value: "ABI", label: "ABI" },
		{ value: "ABQ", label: "ABQ" },
		{ value: "ABR", label: "ABR" },
		{ value: "ABY", label: "ABY" },
		{ value: "ACT", label: "ACT" },
		{ value: "ACV", label: "ACV" },
		{ value: "ACY", label: "ACY" },
		{ value: "ADK", label: "ADK" },
		{ value: "ADQ", label: "ADQ" },
		{ value: "AEX", label: "AEX" },
		{ value: "AGS", label: "AGS" },
		{ value: "ALB", label: "ALB" },
		{ value: "AMA", label: "AMA" },
		{ value: "ANC", label: "ANC" },
		{ value: "ASE", label: "ASE" },
		{ value: "ATL", label: "ATL" },
		{ value: "ATW", label: "ATW" },
		{ value: "AUS", label: "AUS" },
		{ value: "AVL", label: "AVL" },
		{ value: "AVP", label: "AVP" },
		{ value: "AZO", label: "AZO" },
		{ value: "BDL", label: "BDL" },
		{ value: "BET", label: "BET" },
		{ value: "BFL", label: "BFL" },
		{ value: "BGM", label: "BGM" },
		{ value: "BGR", label: "BGR" },
		{ value: "BHM", label: "BHM" },
		{ value: "BIL", label: "BIL" },
		{ value: "BIS", label: "BIS" },
		{ value: "BKG", label: "BKG" },
		{ value: "BLI", label: "BLI" },
		{ value: "BMI", label: "BMI" },
		{ value: "BNA", label: "BNA" },
		{ value: "BOI", label: "BOI" },
		{ value: "BOS", label: "BOS" },
		{ value: "BQK", label: "BQK" },
		{ value: "BQN", label: "BQN" },
		{ value: "BRO", label: "BRO" },
		{ value: "BRW", label: "BRW" },
		{ value: "BTM", label: "BTM" },
		{ value: "BTR", label: "BTR" },
		{ value: "BTV", label: "BTV" },
		{ value: "BUF", label: "BUF" },
		{ value: "BUR", label: "BUR" },
		{ value: "BWI", label: "BWI" },
		{ value: "BZN", label: "BZN" },
		{ value: "CAE", label: "CAE" },
		{ value: "CAK", label: "CAK" },
		{ value: "CDC", label: "CDC" },
		{ value: "CDV", label: "CDV" },
		{ value: "CEC", label: "CEC" },
		{ value: "CHA", label: "CHA" },
		{ value: "CHO", label: "CHO" },
		{ value: "CHS", label: "CHS" },
		{ value: "CIC", label: "CIC" },
		{ value: "CID", label: "CID" },
		{ value: "CLD", label: "CLD" },
		{ value: "CLE", label: "CLE" },
		{ value: "CLL", label: "CLL" },
		{ value: "CLT", label: "CLT" },
		{ value: "CMH", label: "CMH" },
		{ value: "CMI", label: "CMI" },
		{ value: "CMX", label: "CMX" },
		{ value: "COD", label: "COD" },
		{ value: "COS", label: "COS" },
		{ value: "COU", label: "COU" },
		{ value: "CPR", label: "CPR" },
		{ value: "CRP", label: "CRP" },
		{ value: "CRW", label: "CRW" },
		{ value: "CSG", label: "CSG" },
		{ value: "CVG", label: "CVG" },
		{ value: "CWA", label: "CWA" },
		{ value: "CYS", label: "CYS" },
		{ value: "DAB", label: "DAB" },
		{ value: "DAL", label: "DAL" },
		{ value: "DAY", label: "DAY" },
		{ value: "DBQ", label: "DBQ" },
		{ value: "DCA", label: "DCA" },
		{ value: "DEN", label: "DEN" },
		{ value: "DFW", label: "DFW" },
		{ value: "DHN", label: "DHN" },
		{ value: "DLH", label: "DLH" },
		{ value: "DRO", label: "DRO" },
		{ value: "DSM", label: "DSM" },
		{ value: "DTW", label: "DTW" },
		{ value: "EAU", label: "EAU" },
		{ value: "ECP", label: "ECP" },
		{ value: "EGE", label: "EGE" },
		{ value: "EKO", label: "EKO" },
		{ value: "ELM", label: "ELM" },
		{ value: "ELP", label: "ELP" },
		{ value: "ERI", label: "ERI" },
		{ value: "EUG", label: "EUG" },
		{ value: "EVV", label: "EVV" },
		{ value: "EWN", label: "EWN" },
		{ value: "EWR", label: "EWR" },
		{ value: "EYW", label: "EYW" },
		{ value: "FAI", label: "FAI" },
		{ value: "FAR", label: "FAR" },
		{ value: "FAT", label: "FAT" },
		{ value: "FAY", label: "FAY" },
		{ value: "FCA", label: "FCA" },
		{ value: "FLG", label: "FLG" },
		{ value: "FLL", label: "FLL" },
		{ value: "FLO", label: "FLO" },
		{ value: "FNT", label: "FNT" },
		{ value: "FSD", label: "FSD" },
		{ value: "FSM", label: "FSM" },
		{ value: "FWA", label: "FWA" },
		{ value: "GCC", label: "GCC" },
		{ value: "GEG", label: "GEG" },
		{ value: "GFK", label: "GFK" },
		{ value: "GGG", label: "GGG" },
		{ value: "GJT", label: "GJT" },
		{ value: "GNV", label: "GNV" },
		{ value: "GPT", label: "GPT" },
		{ value: "GRB", label: "GRB" },
		{ value: "GRK", label: "GRK" },
		{ value: "GRR", label: "GRR" },
		{ value: "GSO", label: "GSO" },
		{ value: "GSP", label: "GSP" },
		{ value: "GTF", label: "GTF" },
		{ value: "GTR", label: "GTR" },
		{ value: "GUC", label: "GUC" },
		{ value: "GUM", label: "GUM" },
		{ value: "HDN", label: "HDN" },
		{ value: "HLN", label: "HLN" },
		{ value: "HNL", label: "HNL" },
		{ value: "HOU", label: "HOU" },
		{ value: "HPN", label: "HPN" },
		{ value: "HRL", label: "HRL" },
		{ value: "HSV", label: "HSV" },
		{ value: "HTS", label: "HTS" },
		{ value: "IAD", label: "IAD" },
		{ value: "IAH", label: "IAH" },
		{ value: "ICT", label: "ICT" },
		{ value: "IDA", label: "IDA" },
		{ value: "ILM", label: "ILM" },
		{ value: "IND", label: "IND" },
		{ value: "IPL", label: "IPL" },
		{ value: "ISP", label: "ISP" },
		{ value: "ITH", label: "ITH" },
		{ value: "ITO", label: "ITO" },
		{ value: "IYK", label: "IYK" },
		{ value: "JAC", label: "JAC" },
		{ value: "JAN", label: "JAN" },
		{ value: "JAX", label: "JAX" },
		{ value: "JFK", label: "JFK" },
		{ value: "JNU", label: "JNU" },
		{ value: "KOA", label: "KOA" },
		{ value: "KTN", label: "KTN" },
		{ value: "LAN", label: "LAN" },
		{ value: "LAS", label: "LAS" },
		{ value: "LAX", label: "LAX" },
		{ value: "LBB", label: "LBB" },
		{ value: "LCH", label: "LCH" },
		{ value: "LEX", label: "LEX" },
		{ value: "LFT", label: "LFT" },
		{ value: "LGA", label: "LGA" },
		{ value: "LGB", label: "LGB" },
		{ value: "LIH", label: "LIH" },
		{ value: "LIT", label: "LIT" },
		{ value: "LMT", label: "LMT" },
		{ value: "LNK", label: "LNK" },
		{ value: "LRD", label: "LRD" },
		{ value: "LSE", label: "LSE" },
		{ value: "LWB", label: "LWB" },
		{ value: "LWS", label: "LWS" },
		{ value: "LYH", label: "LYH" },
		{ value: "MAF", label: "MAF" },
		{ value: "MBS", label: "MBS" },
		{ value: "MCI", label: "MCI" },
		{ value: "MCO", label: "MCO" },
		{ value: "MDT", label: "MDT" },
		{ value: "MDW", label: "MDW" },
		{ value: "MEI", label: "MEI" },
		{ value: "MEM", label: "MEM" },
		{ value: "MFE", label: "MFE" },
		{ value: "MFR", label: "MFR" },
		{ value: "MGM", label: "MGM" },
		{ value: "MHK", label: "MHK" },
		{ value: "MHT", label: "MHT" },
		{ value: "MIA", label: "MIA" },
		{ value: "MKE", label: "MKE" },
		{ value: "MKG", label: "MKG" },
		{ value: "MLB", label: "MLB" },
		{ value: "MLI", label: "MLI" },
		{ value: "MLU", label: "MLU" },
		{ value: "MMH", label: "MMH" },
		{ value: "MOB", label: "MOB" },
		{ value: "MOD", label: "MOD" },
		{ value: "MOT", label: "MOT" },
		{ value: "MQT", label: "MQT" },
		{ value: "MRY", label: "MRY" },
		{ value: "MSN", label: "MSN" },
		{ value: "MSO", label: "MSO" },
		{ value: "MSP", label: "MSP" },
		{ value: "MSY", label: "MSY" },
		{ value: "MTJ", label: "MTJ" },
		{ value: "MYR", label: "MYR" },
		{ value: "OAJ", label: "OAJ" },
		{ value: "OAK", label: "OAK" },
		{ value: "OGG", label: "OGG" },
		{ value: "OKC", label: "OKC" },
		{ value: "OMA", label: "OMA" },
		{ value: "OME", label: "OME" },
		{ value: "ONT", label: "ONT" },
		{ value: "ORD", label: "ORD" },
		{ value: "ORF", label: "ORF" },
		{ value: "OTH", label: "OTH" },
		{ value: "OTZ", label: "OTZ" },
		{ value: "PAH", label: "PAH" },
		{ value: "PBI", label: "PBI" },
		{ value: "PDX", label: "PDX" },
		{ value: "PHF", label: "PHF" },
		{ value: "PHL", label: "PHL" },
		{ value: "PHX", label: "PHX" },
		{ value: "PIA", label: "PIA" },
		{ value: "PIE", label: "PIE" },
		{ value: "PIH", label: "PIH" },
		{ value: "PIT", label: "PIT" },
		{ value: "PLN", label: "PLN" },
		{ value: "PNS", label: "PNS" },
		{ value: "PSC", label: "PSC" },
		{ value: "PSE", label: "PSE" },
		{ value: "PSG", label: "PSG" },
		{ value: "PSP", label: "PSP" },
		{ value: "PVD", label: "PVD" },
		{ value: "PWM", label: "PWM" },
		{ value: "RAP", label: "RAP" },
		{ value: "RDD", label: "RDD" },
		{ value: "RDM", label: "RDM" },
		{ value: "RDU", label: "RDU" },
		{ value: "RIC", label: "RIC" },
		{ value: "RKS", label: "RKS" },
		{ value: "RNO", label: "RNO" },
		{ value: "ROA", label: "ROA" },
		{ value: "ROC", label: "ROC" },
		{ value: "ROW", label: "ROW" },
		{ value: "RST", label: "RST" },
		{ value: "RSW", label: "RSW" },
		{ value: "SAF", label: "SAF" },
		{ value: "SAN", label: "SAN" },
		{ value: "SAT", label: "SAT" },
		{ value: "SAV", label: "SAV" },
		{ value: "SBA", label: "SBA" },
		{ value: "SBN", label: "SBN" },
		{ value: "SBP", label: "SBP" },
		{ value: "SCC", label: "SCC" },
		{ value: "SCE", label: "SCE" },
		{ value: "SDF", label: "SDF" },
		{ value: "SEA", label: "SEA" },
		{ value: "SFO", label: "SFO" },
		{ value: "SGF", label: "SGF" },
		{ value: "SGU", label: "SGU" },
		{ value: "SHV", label: "SHV" },
		{ value: "SIT", label: "SIT" },
		{ value: "SJC", label: "SJC" },
		{ value: "SJT", label: "SJT" },
		{ value: "SJU", label: "SJU" },
		{ value: "SLC", label: "SLC" },
		{ value: "SMF", label: "SMF" },
		{ value: "SMX", label: "SMX" },
		{ value: "SNA", label: "SNA" },
		{ value: "SPI", label: "SPI" },
		{ value: "SPS", label: "SPS" },
		{ value: "SRQ", label: "SRQ" },
		{ value: "STL", label: "STL" },
		{ value: "STT", label: "STT" },
		{ value: "STX", label: "STX" },
		{ value: "SUN", label: "SUN" },
		{ value: "SWF", label: "SWF" },
		{ value: "SYR", label: "SYR" },
		{ value: "TEX", label: "TEX" },
		{ value: "TLH", label: "TLH" },
		{ value: "TOL", label: "TOL" },
		{ value: "TPA", label: "TPA" },
		{ value: "TRI", label: "TRI" },
		{ value: "TUL", label: "TUL" },
		{ value: "TUS", label: "TUS" },
		{ value: "TVC", label: "TVC" },
		{ value: "TWF", label: "TWF" },
		{ value: "TXK", label: "TXK" },
		{ value: "TYR", label: "TYR" },
		{ value: "TYS", label: "TYS" },
		{ value: "UTM", label: "UTM" },
		{ value: "VLD", label: "VLD" },
		{ value: "VPS", label: "VPS" },
		{ value: "WRG", label: "WRG" },
		{ value: "XNA", label: "XNA" },
		{ value: "YAK", label: "YAK" },
		{ value: "YUM", label: "YUM" },
	];

	const options3 = [
		{ value: "Monday", label: "Monday" },
		{ value: "Tuesday", label: "Tuesday" },
		{ value: "Wednesday", label: "Wednesday" },
		{ value: "Thursday", label: "Thursday" },
		{ value: "Friday", label: "Friday" },
		{ value: "Saturday", label: "Saturday" },
		{ value: "Sunday", label: "Sunday" },
	];

	const set_parameter1 = parameter => {
		console.log("parameter1 has been set to: ", parameter);
		setParameter1(parameter);
	};

	const set_parameter2 = (parameter) => {
		console.log("parameter2 has been set to: ", parameter);
		setParameter2(parameter);
	};

	const set_parameter3 = (parameter) => {
		console.log("parameter3 has been set to: ", parameter);
		setParameter3(parameter);
	}
	const set_parameter4 = (parameter) => {
		console.log("parameter4 has been set to: ", parameter);
		setParameter4(parameter);
	};

	const set_parameter5 = (parameter) => {
		console.log("parameter5 has been set to: ", parameter);
		setParameter5(parameter);
	};

	const set_parameter6 = (parameter) => {
		console.log("parameter6 has been set to: ", parameter);
		setParameter6(parameter);
	}

	const predict = (event) => {
		console.log("parameter1: ", parameter1, "parameter2: ", parameter2, "parameter3: ", parameter3, "parameter4: ", parameter4, "parameter5: ", parameter5, "parameter6: ", parameter6);
		let formData = new FormData();
		var parameter1_val = -1;
		if (parameter1.value === '9E(Endeavor Air)') {
			parameter1_val = 0;
		} else if (parameter1.value === 'AA(American Airlines)') {
			parameter1_val = 1;
		} else if (parameter1.value === 'AS(Alaska Airlines)') {
			parameter1_val = 2;
		} else if (parameter1.value === 'B6(JetBlue)') {
			parameter1_val = 3;
		} else if (parameter1.value === 'CO(Continental Airlines)') {
			parameter1_val = 4;
		} else if (parameter1.value === 'DL(Delta Airlines)') {
			parameter1_val = 5;
		} else if (parameter1.value === 'EV(ExpressJet)') {
			parameter1_val = 6;
		} else if (parameter1.value === 'F9(Frontier Airlines)') {
			parameter1_val = 7;
		} else if (parameter1.value === 'FL(Airtran Airways)') {
			parameter1_val = 8;
		} else if (parameter1.value === 'HA(Hawaiian Airlines)') {
			parameter1_val = 9;
		} else if (parameter1.value === 'MQ(Envoy Air)') {
			parameter1_val = 10;
		} else if (parameter1.value === 'OH(PSA Airlines)') {
			parameter1_val = 11;
		} else if (parameter1.value === 'OO(Skywest Airlines)') {
			parameter1_val = 12;
		} else if (parameter1.value === 'UA(United Airlines)') {
			parameter1_val = 13;
		} else if (parameter1.value === 'US(US Airways)') {
			parameter1_val = 14;
		} else if (parameter1.value === 'WN(Southwest Airlines)') {
			parameter1_val = 15;
		} else if (parameter1.value === 'XE(JSX)') {
			parameter1_val = 16;
		} else if (parameter1.value === 'YV(Mesa Airlines)') {
			parameter1_val = 17;
		}
		formData.append("parameter1", parameter1_val);
		var parameter2_val = -1;
		if (parameter2.value === 'ABE') { parameter2_val = 0; }
		else if (parameter2.value === 'ABI') { parameter2_val = 1; }
		else if (parameter2.value === 'ABQ') { parameter2_val = 2; }
		else if (parameter2.value === 'ABR') { parameter2_val = 3; }
		else if (parameter2.value === 'ABY') { parameter2_val = 4; }
		else if (parameter2.value === 'ACT') { parameter2_val = 5; }
		else if (parameter2.value === 'ACV') { parameter2_val = 6; }
		else if (parameter2.value === 'ACY') { parameter2_val = 7; }
		else if (parameter2.value === 'ADK') { parameter2_val = 8; }
		else if (parameter2.value === 'ADQ') { parameter2_val = 9; }
		else if (parameter2.value === 'AEX') { parameter2_val = 10; }
		else if (parameter2.value === 'AGS') { parameter2_val = 11; }
		else if (parameter2.value === 'ALB') { parameter2_val = 12; }
		else if (parameter2.value === 'AMA') { parameter2_val = 13; }
		else if (parameter2.value === 'ANC') { parameter2_val = 14; }
		else if (parameter2.value === 'ASE') { parameter2_val = 15; }
		else if (parameter2.value === 'ATL') { parameter2_val = 16; }
		else if (parameter2.value === 'ATW') { parameter2_val = 17; }
		else if (parameter2.value === 'AUS') { parameter2_val = 18; }
		else if (parameter2.value === 'AVL') { parameter2_val = 19; }
		else if (parameter2.value === 'AVP') { parameter2_val = 20; }
		else if (parameter2.value === 'AZO') { parameter2_val = 21; }
		else if (parameter2.value === 'BDL') { parameter2_val = 22; }
		else if (parameter2.value === 'BET') { parameter2_val = 23; }
		else if (parameter2.value === 'BFL') { parameter2_val = 24; }
		else if (parameter2.value === 'BGM') { parameter2_val = 25; }
		else if (parameter2.value === 'BGR') { parameter2_val = 26; }
		else if (parameter2.value === 'BHM') { parameter2_val = 27; }
		else if (parameter2.value === 'BIL') { parameter2_val = 28; }
		else if (parameter2.value === 'BIS') { parameter2_val = 29; }
		else if (parameter2.value === 'BKG') { parameter2_val = 30; }
		else if (parameter2.value === 'BLI') { parameter2_val = 31; }
		else if (parameter2.value === 'BMI') { parameter2_val = 32; }
		else if (parameter2.value === 'BNA') { parameter2_val = 33; }
		else if (parameter2.value === 'BOI') { parameter2_val = 34; }
		else if (parameter2.value === 'BOS') { parameter2_val = 35; }
		else if (parameter2.value === 'BQK') { parameter2_val = 36; }
		else if (parameter2.value === 'BQN') { parameter2_val = 37; }
		else if (parameter2.value === 'BRO') { parameter2_val = 38; }
		else if (parameter2.value === 'BRW') { parameter2_val = 39; }
		else if (parameter2.value === 'BTM') { parameter2_val = 40; }
		else if (parameter2.value === 'BTR') { parameter2_val = 41; }
		else if (parameter2.value === 'BTV') { parameter2_val = 42; }
		else if (parameter2.value === 'BUF') { parameter2_val = 43; }
		else if (parameter2.value === 'BUR') { parameter2_val = 44; }
		else if (parameter2.value === 'BWI') { parameter2_val = 45; }
		else if (parameter2.value === 'BZN') { parameter2_val = 46; }
		else if (parameter2.value === 'CAE') { parameter2_val = 47; }
		else if (parameter2.value === 'CAK') { parameter2_val = 48; }
		else if (parameter2.value === 'CDC') { parameter2_val = 49; }
		else if (parameter2.value === 'CDV') { parameter2_val = 50; }
		else if (parameter2.value === 'CEC') { parameter2_val = 51; }
		else if (parameter2.value === 'CHA') { parameter2_val = 52; }
		else if (parameter2.value === 'CHO') { parameter2_val = 53; }
		else if (parameter2.value === 'CHS') { parameter2_val = 54; }
		else if (parameter2.value === 'CIC') { parameter2_val = 55; }
		else if (parameter2.value === 'CID') { parameter2_val = 56; }
		else if (parameter2.value === 'CLD') { parameter2_val = 57; }
		else if (parameter2.value === 'CLE') { parameter2_val = 58; }
		else if (parameter2.value === 'CLL') { parameter2_val = 59; }
		else if (parameter2.value === 'CLT') { parameter2_val = 60; }
		else if (parameter2.value === 'CMH') { parameter2_val = 61; }
		else if (parameter2.value === 'CMI') { parameter2_val = 62; }
		else if (parameter2.value === 'CMX') { parameter2_val = 63; }
		else if (parameter2.value === 'COD') { parameter2_val = 64; }
		else if (parameter2.value === 'COS') { parameter2_val = 65; }
		else if (parameter2.value === 'COU') { parameter2_val = 66; }
		else if (parameter2.value === 'CPR') { parameter2_val = 67; }
		else if (parameter2.value === 'CRP') { parameter2_val = 68; }
		else if (parameter2.value === 'CRW') { parameter2_val = 69; }
		else if (parameter2.value === 'CSG') { parameter2_val = 70; }
		else if (parameter2.value === 'CVG') { parameter2_val = 71; }
		else if (parameter2.value === 'CWA') { parameter2_val = 72; }
		else if (parameter2.value === 'CYS') { parameter2_val = 73; }
		else if (parameter2.value === 'DAB') { parameter2_val = 74; }
		else if (parameter2.value === 'DAL') { parameter2_val = 75; }
		else if (parameter2.value === 'DAY') { parameter2_val = 76; }
		else if (parameter2.value === 'DBQ') { parameter2_val = 77; }
		else if (parameter2.value === 'DCA') { parameter2_val = 78; }
		else if (parameter2.value === 'DEN') { parameter2_val = 79; }
		else if (parameter2.value === 'DFW') { parameter2_val = 80; }
		else if (parameter2.value === 'DHN') { parameter2_val = 81; }
		else if (parameter2.value === 'DLH') { parameter2_val = 82; }
		else if (parameter2.value === 'DRO') { parameter2_val = 83; }
		else if (parameter2.value === 'DSM') { parameter2_val = 84; }
		else if (parameter2.value === 'DTW') { parameter2_val = 85; }
		else if (parameter2.value === 'EAU') { parameter2_val = 86; }
		else if (parameter2.value === 'ECP') { parameter2_val = 87; }
		else if (parameter2.value === 'EGE') { parameter2_val = 88; }
		else if (parameter2.value === 'EKO') { parameter2_val = 89; }
		else if (parameter2.value === 'ELM') { parameter2_val = 90; }
		else if (parameter2.value === 'ELP') { parameter2_val = 91; }
		else if (parameter2.value === 'ERI') { parameter2_val = 92; }
		else if (parameter2.value === 'EUG') { parameter2_val = 93; }
		else if (parameter2.value === 'EVV') { parameter2_val = 94; }
		else if (parameter2.value === 'EWN') { parameter2_val = 95; }
		else if (parameter2.value === 'EWR') { parameter2_val = 96; }
		else if (parameter2.value === 'EYW') { parameter2_val = 97; }
		else if (parameter2.value === 'FAI') { parameter2_val = 98; }
		else if (parameter2.value === 'FAR') { parameter2_val = 99; }
		else if (parameter2.value === 'FAT') { parameter2_val = 100; }
		else if (parameter2.value === 'FAY') { parameter2_val = 101; }
		else if (parameter2.value === 'FCA') { parameter2_val = 102; }
		else if (parameter2.value === 'FLG') { parameter2_val = 103; }
		else if (parameter2.value === 'FLL') { parameter2_val = 104; }
		else if (parameter2.value === 'FLO') { parameter2_val = 105; }
		else if (parameter2.value === 'FNT') { parameter2_val = 106; }
		else if (parameter2.value === 'FSD') { parameter2_val = 107; }
		else if (parameter2.value === 'FSM') { parameter2_val = 108; }
		else if (parameter2.value === 'FWA') { parameter2_val = 109; }
		else if (parameter2.value === 'GCC') { parameter2_val = 110; }
		else if (parameter2.value === 'GEG') { parameter2_val = 111; }
		else if (parameter2.value === 'GFK') { parameter2_val = 112; }
		else if (parameter2.value === 'GGG') { parameter2_val = 113; }
		else if (parameter2.value === 'GJT') { parameter2_val = 114; }
		else if (parameter2.value === 'GNV') { parameter2_val = 115; }
		else if (parameter2.value === 'GPT') { parameter2_val = 116; }
		else if (parameter2.value === 'GRB') { parameter2_val = 117; }
		else if (parameter2.value === 'GRK') { parameter2_val = 118; }
		else if (parameter2.value === 'GRR') { parameter2_val = 119; }
		else if (parameter2.value === 'GSO') { parameter2_val = 120; }
		else if (parameter2.value === 'GSP') { parameter2_val = 121; }
		else if (parameter2.value === 'GTF') { parameter2_val = 122; }
		else if (parameter2.value === 'GTR') { parameter2_val = 123; }
		else if (parameter2.value === 'GUC') { parameter2_val = 124; }
		else if (parameter2.value === 'GUM') { parameter2_val = 125; }
		else if (parameter2.value === 'HDN') { parameter2_val = 126; }
		else if (parameter2.value === 'HLN') { parameter2_val = 127; }
		else if (parameter2.value === 'HNL') { parameter2_val = 128; }
		else if (parameter2.value === 'HOU') { parameter2_val = 129; }
		else if (parameter2.value === 'HPN') { parameter2_val = 130; }
		else if (parameter2.value === 'HRL') { parameter2_val = 131; }
		else if (parameter2.value === 'HSV') { parameter2_val = 132; }
		else if (parameter2.value === 'HTS') { parameter2_val = 133; }
		else if (parameter2.value === 'IAD') { parameter2_val = 134; }
		else if (parameter2.value === 'IAH') { parameter2_val = 135; }
		else if (parameter2.value === 'ICT') { parameter2_val = 136; }
		else if (parameter2.value === 'IDA') { parameter2_val = 137; }
		else if (parameter2.value === 'ILM') { parameter2_val = 138; }
		else if (parameter2.value === 'IND') { parameter2_val = 139; }
		else if (parameter2.value === 'IPL') { parameter2_val = 140; }
		else if (parameter2.value === 'ISP') { parameter2_val = 141; }
		else if (parameter2.value === 'ITH') { parameter2_val = 142; }
		else if (parameter2.value === 'ITO') { parameter2_val = 143; }
		else if (parameter2.value === 'IYK') { parameter2_val = 144; }
		else if (parameter2.value === 'JAC') { parameter2_val = 145; }
		else if (parameter2.value === 'JAN') { parameter2_val = 146; }
		else if (parameter2.value === 'JAX') { parameter2_val = 147; }
		else if (parameter2.value === 'JFK') { parameter2_val = 148; }
		else if (parameter2.value === 'JNU') { parameter2_val = 149; }
		else if (parameter2.value === 'KOA') { parameter2_val = 150; }
		else if (parameter2.value === 'KTN') { parameter2_val = 151; }
		else if (parameter2.value === 'LAN') { parameter2_val = 152; }
		else if (parameter2.value === 'LAS') { parameter2_val = 153; }
		else if (parameter2.value === 'LAX') { parameter2_val = 154; }
		else if (parameter2.value === 'LBB') { parameter2_val = 155; }
		else if (parameter2.value === 'LCH') { parameter2_val = 156; }
		else if (parameter2.value === 'LEX') { parameter2_val = 157; }
		else if (parameter2.value === 'LFT') { parameter2_val = 158; }
		else if (parameter2.value === 'LGA') { parameter2_val = 159; }
		else if (parameter2.value === 'LGB') { parameter2_val = 160; }
		else if (parameter2.value === 'LIH') { parameter2_val = 161; }
		else if (parameter2.value === 'LIT') { parameter2_val = 162; }
		else if (parameter2.value === 'LMT') { parameter2_val = 163; }
		else if (parameter2.value === 'LNK') { parameter2_val = 164; }
		else if (parameter2.value === 'LRD') { parameter2_val = 165; }
		else if (parameter2.value === 'LSE') { parameter2_val = 166; }
		else if (parameter2.value === 'LWB') { parameter2_val = 167; }
		else if (parameter2.value === 'LWS') { parameter2_val = 168; }
		else if (parameter2.value === 'LYH') { parameter2_val = 169; }
		else if (parameter2.value === 'MAF') { parameter2_val = 170; }
		else if (parameter2.value === 'MBS') { parameter2_val = 171; }
		else if (parameter2.value === 'MCI') { parameter2_val = 172; }
		else if (parameter2.value === 'MCO') { parameter2_val = 173; }
		else if (parameter2.value === 'MDT') { parameter2_val = 174; }
		else if (parameter2.value === 'MDW') { parameter2_val = 175; }
		else if (parameter2.value === 'MEI') { parameter2_val = 176; }
		else if (parameter2.value === 'MEM') { parameter2_val = 177; }
		else if (parameter2.value === 'MFE') { parameter2_val = 178; }
		else if (parameter2.value === 'MFR') { parameter2_val = 179; }
		else if (parameter2.value === 'MGM') { parameter2_val = 180; }
		else if (parameter2.value === 'MHK') { parameter2_val = 181; }
		else if (parameter2.value === 'MHT') { parameter2_val = 182; }
		else if (parameter2.value === 'MIA') { parameter2_val = 183; }
		else if (parameter2.value === 'MKE') { parameter2_val = 184; }
		else if (parameter2.value === 'MKG') { parameter2_val = 185; }
		else if (parameter2.value === 'MLB') { parameter2_val = 186; }
		else if (parameter2.value === 'MLI') { parameter2_val = 187; }
		else if (parameter2.value === 'MLU') { parameter2_val = 188; }
		else if (parameter2.value === 'MMH') { parameter2_val = 189; }
		else if (parameter2.value === 'MOB') { parameter2_val = 190; }
		else if (parameter2.value === 'MOD') { parameter2_val = 191; }
		else if (parameter2.value === 'MOT') { parameter2_val = 192; }
		else if (parameter2.value === 'MQT') { parameter2_val = 193; }
		else if (parameter2.value === 'MRY') { parameter2_val = 194; }
		else if (parameter2.value === 'MSN') { parameter2_val = 195; }
		else if (parameter2.value === 'MSO') { parameter2_val = 196; }
		else if (parameter2.value === 'MSP') { parameter2_val = 197; }
		else if (parameter2.value === 'MSY') { parameter2_val = 198; }
		else if (parameter2.value === 'MTJ') { parameter2_val = 199; }
		else if (parameter2.value === 'MYR') { parameter2_val = 200; }
		else if (parameter2.value === 'OAJ') { parameter2_val = 201; }
		else if (parameter2.value === 'OAK') { parameter2_val = 202; }
		else if (parameter2.value === 'OGG') { parameter2_val = 203; }
		else if (parameter2.value === 'OKC') { parameter2_val = 204; }
		else if (parameter2.value === 'OMA') { parameter2_val = 205; }
		else if (parameter2.value === 'OME') { parameter2_val = 206; }
		else if (parameter2.value === 'ONT') { parameter2_val = 207; }
		else if (parameter2.value === 'ORD') { parameter2_val = 208; }
		else if (parameter2.value === 'ORF') { parameter2_val = 209; }
		else if (parameter2.value === 'OTH') { parameter2_val = 210; }
		else if (parameter2.value === 'OTZ') { parameter2_val = 211; }
		else if (parameter2.value === 'PAH') { parameter2_val = 212; }
		else if (parameter2.value === 'PBI') { parameter2_val = 213; }
		else if (parameter2.value === 'PDX') { parameter2_val = 214; }
		else if (parameter2.value === 'PHF') { parameter2_val = 215; }
		else if (parameter2.value === 'PHL') { parameter2_val = 216; }
		else if (parameter2.value === 'PHX') { parameter2_val = 217; }
		else if (parameter2.value === 'PIA') { parameter2_val = 218; }
		else if (parameter2.value === 'PIE') { parameter2_val = 219; }
		else if (parameter2.value === 'PIH') { parameter2_val = 220; }
		else if (parameter2.value === 'PIT') { parameter2_val = 221; }
		else if (parameter2.value === 'PLN') { parameter2_val = 222; }
		else if (parameter2.value === 'PNS') { parameter2_val = 223; }
		else if (parameter2.value === 'PSC') { parameter2_val = 224; }
		else if (parameter2.value === 'PSE') { parameter2_val = 225; }
		else if (parameter2.value === 'PSG') { parameter2_val = 226; }
		else if (parameter2.value === 'PSP') { parameter2_val = 227; }
		else if (parameter2.value === 'PVD') { parameter2_val = 228; }
		else if (parameter2.value === 'PWM') { parameter2_val = 229; }
		else if (parameter2.value === 'RAP') { parameter2_val = 230; }
		else if (parameter2.value === 'RDD') { parameter2_val = 231; }
		else if (parameter2.value === 'RDM') { parameter2_val = 232; }
		else if (parameter2.value === 'RDU') { parameter2_val = 233; }
		else if (parameter2.value === 'RIC') { parameter2_val = 234; }
		else if (parameter2.value === 'RKS') { parameter2_val = 235; }
		else if (parameter2.value === 'RNO') { parameter2_val = 236; }
		else if (parameter2.value === 'ROA') { parameter2_val = 237; }
		else if (parameter2.value === 'ROC') { parameter2_val = 238; }
		else if (parameter2.value === 'ROW') { parameter2_val = 239; }
		else if (parameter2.value === 'RST') { parameter2_val = 240; }
		else if (parameter2.value === 'RSW') { parameter2_val = 241; }
		else if (parameter2.value === 'SAF') { parameter2_val = 242; }
		else if (parameter2.value === 'SAN') { parameter2_val = 243; }
		else if (parameter2.value === 'SAT') { parameter2_val = 244; }
		else if (parameter2.value === 'SAV') { parameter2_val = 245; }
		else if (parameter2.value === 'SBA') { parameter2_val = 246; }
		else if (parameter2.value === 'SBN') { parameter2_val = 247; }
		else if (parameter2.value === 'SBP') { parameter2_val = 248; }
		else if (parameter2.value === 'SCC') { parameter2_val = 249; }
		else if (parameter2.value === 'SCE') { parameter2_val = 250; }
		else if (parameter2.value === 'SDF') { parameter2_val = 251; }
		else if (parameter2.value === 'SEA') { parameter2_val = 252; }
		else if (parameter2.value === 'SFO') { parameter2_val = 253; }
		else if (parameter2.value === 'SGF') { parameter2_val = 254; }
		else if (parameter2.value === 'SGU') { parameter2_val = 255; }
		else if (parameter2.value === 'SHV') { parameter2_val = 256; }
		else if (parameter2.value === 'SIT') { parameter2_val = 257; }
		else if (parameter2.value === 'SJC') { parameter2_val = 258; }
		else if (parameter2.value === 'SJT') { parameter2_val = 259; }
		else if (parameter2.value === 'SJU') { parameter2_val = 260; }
		else if (parameter2.value === 'SLC') { parameter2_val = 261; }
		else if (parameter2.value === 'SMF') { parameter2_val = 262; }
		else if (parameter2.value === 'SMX') { parameter2_val = 263; }
		else if (parameter2.value === 'SNA') { parameter2_val = 264; }
		else if (parameter2.value === 'SPI') { parameter2_val = 265; }
		else if (parameter2.value === 'SPS') { parameter2_val = 266; }
		else if (parameter2.value === 'SRQ') { parameter2_val = 267; }
		else if (parameter2.value === 'STL') { parameter2_val = 268; }
		else if (parameter2.value === 'STT') { parameter2_val = 269; }
		else if (parameter2.value === 'STX') { parameter2_val = 270; }
		else if (parameter2.value === 'SUN') { parameter2_val = 271; }
		else if (parameter2.value === 'SWF') { parameter2_val = 272; }
		else if (parameter2.value === 'SYR') { parameter2_val = 273; }
		else if (parameter2.value === 'TEX') { parameter2_val = 274; }
		else if (parameter2.value === 'TLH') { parameter2_val = 275; }
		else if (parameter2.value === 'TOL') { parameter2_val = 276; }
		else if (parameter2.value === 'TPA') { parameter2_val = 277; }
		else if (parameter2.value === 'TRI') { parameter2_val = 278; }
		else if (parameter2.value === 'TUL') { parameter2_val = 279; }
		else if (parameter2.value === 'TUS') { parameter2_val = 280; }
		else if (parameter2.value === 'TVC') { parameter2_val = 281; }
		else if (parameter2.value === 'TWF') { parameter2_val = 282; }
		else if (parameter2.value === 'TXK') { parameter2_val = 283; }
		else if (parameter2.value === 'TYR') { parameter2_val = 284; }
		else if (parameter2.value === 'TYS') { parameter2_val = 285; }
		else if (parameter2.value === 'UTM') { parameter2_val = 286; }
		else if (parameter2.value === 'VLD') { parameter2_val = 287; }
		else if (parameter2.value === 'VPS') { parameter2_val = 288; }
		else if (parameter2.value === 'WRG') { parameter2_val = 289; }
		else if (parameter2.value === 'XNA') { parameter2_val = 290; }
		else if (parameter2.value === 'YAK') { parameter2_val = 291; }
		else if (parameter2.value === 'YUM') { parameter2_val = 292; }
		formData.append("parameter2", parameter2_val);
		var parameter3_val = -1;
		if (parameter3.value === 'ABE') { parameter3_val = 0; }
		else if (parameter3.value === 'ABI') { parameter3_val = 1; }
		else if (parameter3.value === 'ABQ') { parameter3_val = 2; }
		else if (parameter3.value === 'ABR') { parameter3_val = 3; }
		else if (parameter3.value === 'ABY') { parameter3_val = 4; }
		else if (parameter3.value === 'ACT') { parameter3_val = 5; }
		else if (parameter3.value === 'ACV') { parameter3_val = 6; }
		else if (parameter3.value === 'ACY') { parameter3_val = 7; }
		else if (parameter3.value === 'ADK') { parameter3_val = 8; }
		else if (parameter3.value === 'ADQ') { parameter3_val = 9; }
		else if (parameter3.value === 'AEX') { parameter3_val = 10; }
		else if (parameter3.value === 'AGS') { parameter3_val = 11; }
		else if (parameter3.value === 'ALB') { parameter3_val = 12; }
		else if (parameter3.value === 'AMA') { parameter3_val = 13; }
		else if (parameter3.value === 'ANC') { parameter3_val = 14; }
		else if (parameter3.value === 'ASE') { parameter3_val = 15; }
		else if (parameter3.value === 'ATL') { parameter3_val = 16; }
		else if (parameter3.value === 'ATW') { parameter3_val = 17; }
		else if (parameter3.value === 'AUS') { parameter3_val = 18; }
		else if (parameter3.value === 'AVL') { parameter3_val = 19; }
		else if (parameter3.value === 'AVP') { parameter3_val = 20; }
		else if (parameter3.value === 'AZO') { parameter3_val = 21; }
		else if (parameter3.value === 'BDL') { parameter3_val = 22; }
		else if (parameter3.value === 'BET') { parameter3_val = 23; }
		else if (parameter3.value === 'BFL') { parameter3_val = 24; }
		else if (parameter3.value === 'BGM') { parameter3_val = 25; }
		else if (parameter3.value === 'BGR') { parameter3_val = 26; }
		else if (parameter3.value === 'BHM') { parameter3_val = 27; }
		else if (parameter3.value === 'BIL') { parameter3_val = 28; }
		else if (parameter3.value === 'BIS') { parameter3_val = 29; }
		else if (parameter3.value === 'BKG') { parameter3_val = 30; }
		else if (parameter3.value === 'BLI') { parameter3_val = 31; }
		else if (parameter3.value === 'BMI') { parameter3_val = 32; }
		else if (parameter3.value === 'BNA') { parameter3_val = 33; }
		else if (parameter3.value === 'BOI') { parameter3_val = 34; }
		else if (parameter3.value === 'BOS') { parameter3_val = 35; }
		else if (parameter3.value === 'BQK') { parameter3_val = 36; }
		else if (parameter3.value === 'BQN') { parameter3_val = 37; }
		else if (parameter3.value === 'BRO') { parameter3_val = 38; }
		else if (parameter3.value === 'BRW') { parameter3_val = 39; }
		else if (parameter3.value === 'BTM') { parameter3_val = 40; }
		else if (parameter3.value === 'BTR') { parameter3_val = 41; }
		else if (parameter3.value === 'BTV') { parameter3_val = 42; }
		else if (parameter3.value === 'BUF') { parameter3_val = 43; }
		else if (parameter3.value === 'BUR') { parameter3_val = 44; }
		else if (parameter3.value === 'BWI') { parameter3_val = 45; }
		else if (parameter3.value === 'BZN') { parameter3_val = 46; }
		else if (parameter3.value === 'CAE') { parameter3_val = 47; }
		else if (parameter3.value === 'CAK') { parameter3_val = 48; }
		else if (parameter3.value === 'CDC') { parameter3_val = 49; }
		else if (parameter3.value === 'CDV') { parameter3_val = 50; }
		else if (parameter3.value === 'CEC') { parameter3_val = 51; }
		else if (parameter3.value === 'CHA') { parameter3_val = 52; }
		else if (parameter3.value === 'CHO') { parameter3_val = 53; }
		else if (parameter3.value === 'CHS') { parameter3_val = 54; }
		else if (parameter3.value === 'CIC') { parameter3_val = 55; }
		else if (parameter3.value === 'CID') { parameter3_val = 56; }
		else if (parameter3.value === 'CLD') { parameter3_val = 57; }
		else if (parameter3.value === 'CLE') { parameter3_val = 58; }
		else if (parameter3.value === 'CLL') { parameter3_val = 59; }
		else if (parameter3.value === 'CLT') { parameter3_val = 60; }
		else if (parameter3.value === 'CMH') { parameter3_val = 61; }
		else if (parameter3.value === 'CMI') { parameter3_val = 62; }
		else if (parameter3.value === 'CMX') { parameter3_val = 63; }
		else if (parameter3.value === 'COD') { parameter3_val = 64; }
		else if (parameter3.value === 'COS') { parameter3_val = 65; }
		else if (parameter3.value === 'COU') { parameter3_val = 66; }
		else if (parameter3.value === 'CPR') { parameter3_val = 67; }
		else if (parameter3.value === 'CRP') { parameter3_val = 68; }
		else if (parameter3.value === 'CRW') { parameter3_val = 69; }
		else if (parameter3.value === 'CSG') { parameter3_val = 70; }
		else if (parameter3.value === 'CVG') { parameter3_val = 71; }
		else if (parameter3.value === 'CWA') { parameter3_val = 72; }
		else if (parameter3.value === 'CYS') { parameter3_val = 73; }
		else if (parameter3.value === 'DAB') { parameter3_val = 74; }
		else if (parameter3.value === 'DAL') { parameter3_val = 75; }
		else if (parameter3.value === 'DAY') { parameter3_val = 76; }
		else if (parameter3.value === 'DBQ') { parameter3_val = 77; }
		else if (parameter3.value === 'DCA') { parameter3_val = 78; }
		else if (parameter3.value === 'DEN') { parameter3_val = 79; }
		else if (parameter3.value === 'DFW') { parameter3_val = 80; }
		else if (parameter3.value === 'DHN') { parameter3_val = 81; }
		else if (parameter3.value === 'DLH') { parameter3_val = 82; }
		else if (parameter3.value === 'DRO') { parameter3_val = 83; }
		else if (parameter3.value === 'DSM') { parameter3_val = 84; }
		else if (parameter3.value === 'DTW') { parameter3_val = 85; }
		else if (parameter3.value === 'EAU') { parameter3_val = 86; }
		else if (parameter3.value === 'ECP') { parameter3_val = 87; }
		else if (parameter3.value === 'EGE') { parameter3_val = 88; }
		else if (parameter3.value === 'EKO') { parameter3_val = 89; }
		else if (parameter3.value === 'ELM') { parameter3_val = 90; }
		else if (parameter3.value === 'ELP') { parameter3_val = 91; }
		else if (parameter3.value === 'ERI') { parameter3_val = 92; }
		else if (parameter3.value === 'EUG') { parameter3_val = 93; }
		else if (parameter3.value === 'EVV') { parameter3_val = 94; }
		else if (parameter3.value === 'EWN') { parameter3_val = 95; }
		else if (parameter3.value === 'EWR') { parameter3_val = 96; }
		else if (parameter3.value === 'EYW') { parameter3_val = 97; }
		else if (parameter3.value === 'FAI') { parameter3_val = 98; }
		else if (parameter3.value === 'FAR') { parameter3_val = 99; }
		else if (parameter3.value === 'FAT') { parameter3_val = 100; }
		else if (parameter3.value === 'FAY') { parameter3_val = 101; }
		else if (parameter3.value === 'FCA') { parameter3_val = 102; }
		else if (parameter3.value === 'FLG') { parameter3_val = 103; }
		else if (parameter3.value === 'FLL') { parameter3_val = 104; }
		else if (parameter3.value === 'FLO') { parameter3_val = 105; }
		else if (parameter3.value === 'FNT') { parameter3_val = 106; }
		else if (parameter3.value === 'FSD') { parameter3_val = 107; }
		else if (parameter3.value === 'FSM') { parameter3_val = 108; }
		else if (parameter3.value === 'FWA') { parameter3_val = 109; }
		else if (parameter3.value === 'GCC') { parameter3_val = 110; }
		else if (parameter3.value === 'GEG') { parameter3_val = 111; }
		else if (parameter3.value === 'GFK') { parameter3_val = 112; }
		else if (parameter3.value === 'GGG') { parameter3_val = 113; }
		else if (parameter3.value === 'GJT') { parameter3_val = 114; }
		else if (parameter3.value === 'GNV') { parameter3_val = 115; }
		else if (parameter3.value === 'GPT') { parameter3_val = 116; }
		else if (parameter3.value === 'GRB') { parameter3_val = 117; }
		else if (parameter3.value === 'GRK') { parameter3_val = 118; }
		else if (parameter3.value === 'GRR') { parameter3_val = 119; }
		else if (parameter3.value === 'GSO') { parameter3_val = 120; }
		else if (parameter3.value === 'GSP') { parameter3_val = 121; }
		else if (parameter3.value === 'GTF') { parameter3_val = 122; }
		else if (parameter3.value === 'GTR') { parameter3_val = 123; }
		else if (parameter3.value === 'GUC') { parameter3_val = 124; }
		else if (parameter3.value === 'GUM') { parameter3_val = 125; }
		else if (parameter3.value === 'HDN') { parameter3_val = 126; }
		else if (parameter3.value === 'HLN') { parameter3_val = 127; }
		else if (parameter3.value === 'HNL') { parameter3_val = 128; }
		else if (parameter3.value === 'HOU') { parameter3_val = 129; }
		else if (parameter3.value === 'HPN') { parameter3_val = 130; }
		else if (parameter3.value === 'HRL') { parameter3_val = 131; }
		else if (parameter3.value === 'HSV') { parameter3_val = 132; }
		else if (parameter3.value === 'HTS') { parameter3_val = 133; }
		else if (parameter3.value === 'IAD') { parameter3_val = 134; }
		else if (parameter3.value === 'IAH') { parameter3_val = 135; }
		else if (parameter3.value === 'ICT') { parameter3_val = 136; }
		else if (parameter3.value === 'IDA') { parameter3_val = 137; }
		else if (parameter3.value === 'ILM') { parameter3_val = 138; }
		else if (parameter3.value === 'IND') { parameter3_val = 139; }
		else if (parameter3.value === 'IPL') { parameter3_val = 140; }
		else if (parameter3.value === 'ISP') { parameter3_val = 141; }
		else if (parameter3.value === 'ITH') { parameter3_val = 142; }
		else if (parameter3.value === 'ITO') { parameter3_val = 143; }
		else if (parameter3.value === 'IYK') { parameter3_val = 144; }
		else if (parameter3.value === 'JAC') { parameter3_val = 145; }
		else if (parameter3.value === 'JAN') { parameter3_val = 146; }
		else if (parameter3.value === 'JAX') { parameter3_val = 147; }
		else if (parameter3.value === 'JFK') { parameter3_val = 148; }
		else if (parameter3.value === 'JNU') { parameter3_val = 149; }
		else if (parameter3.value === 'KOA') { parameter3_val = 150; }
		else if (parameter3.value === 'KTN') { parameter3_val = 151; }
		else if (parameter3.value === 'LAN') { parameter3_val = 152; }
		else if (parameter3.value === 'LAS') { parameter3_val = 153; }
		else if (parameter3.value === 'LAX') { parameter3_val = 154; }
		else if (parameter3.value === 'LBB') { parameter3_val = 155; }
		else if (parameter3.value === 'LCH') { parameter3_val = 156; }
		else if (parameter3.value === 'LEX') { parameter3_val = 157; }
		else if (parameter3.value === 'LFT') { parameter3_val = 158; }
		else if (parameter3.value === 'LGA') { parameter3_val = 159; }
		else if (parameter3.value === 'LGB') { parameter3_val = 160; }
		else if (parameter3.value === 'LIH') { parameter3_val = 161; }
		else if (parameter3.value === 'LIT') { parameter3_val = 162; }
		else if (parameter3.value === 'LMT') { parameter3_val = 163; }
		else if (parameter3.value === 'LNK') { parameter3_val = 164; }
		else if (parameter3.value === 'LRD') { parameter3_val = 165; }
		else if (parameter3.value === 'LSE') { parameter3_val = 166; }
		else if (parameter3.value === 'LWB') { parameter3_val = 167; }
		else if (parameter3.value === 'LWS') { parameter3_val = 168; }
		else if (parameter3.value === 'LYH') { parameter3_val = 169; }
		else if (parameter3.value === 'MAF') { parameter3_val = 170; }
		else if (parameter3.value === 'MBS') { parameter3_val = 171; }
		else if (parameter3.value === 'MCI') { parameter3_val = 172; }
		else if (parameter3.value === 'MCO') { parameter3_val = 173; }
		else if (parameter3.value === 'MDT') { parameter3_val = 174; }
		else if (parameter3.value === 'MDW') { parameter3_val = 175; }
		else if (parameter3.value === 'MEI') { parameter3_val = 176; }
		else if (parameter3.value === 'MEM') { parameter3_val = 177; }
		else if (parameter3.value === 'MFE') { parameter3_val = 178; }
		else if (parameter3.value === 'MFR') { parameter3_val = 179; }
		else if (parameter3.value === 'MGM') { parameter3_val = 180; }
		else if (parameter3.value === 'MHK') { parameter3_val = 181; }
		else if (parameter3.value === 'MHT') { parameter3_val = 182; }
		else if (parameter3.value === 'MIA') { parameter3_val = 183; }
		else if (parameter3.value === 'MKE') { parameter3_val = 184; }
		else if (parameter3.value === 'MKG') { parameter3_val = 185; }
		else if (parameter3.value === 'MLB') { parameter3_val = 186; }
		else if (parameter3.value === 'MLI') { parameter3_val = 187; }
		else if (parameter3.value === 'MLU') { parameter3_val = 188; }
		else if (parameter3.value === 'MMH') { parameter3_val = 189; }
		else if (parameter3.value === 'MOB') { parameter3_val = 190; }
		else if (parameter3.value === 'MOD') { parameter3_val = 191; }
		else if (parameter3.value === 'MOT') { parameter3_val = 192; }
		else if (parameter3.value === 'MQT') { parameter3_val = 193; }
		else if (parameter3.value === 'MRY') { parameter3_val = 194; }
		else if (parameter3.value === 'MSN') { parameter3_val = 195; }
		else if (parameter3.value === 'MSO') { parameter3_val = 196; }
		else if (parameter3.value === 'MSP') { parameter3_val = 197; }
		else if (parameter3.value === 'MSY') { parameter3_val = 198; }
		else if (parameter3.value === 'MTJ') { parameter3_val = 199; }
		else if (parameter3.value === 'MYR') { parameter3_val = 200; }
		else if (parameter3.value === 'OAJ') { parameter3_val = 201; }
		else if (parameter3.value === 'OAK') { parameter3_val = 202; }
		else if (parameter3.value === 'OGG') { parameter3_val = 203; }
		else if (parameter3.value === 'OKC') { parameter3_val = 204; }
		else if (parameter3.value === 'OMA') { parameter3_val = 205; }
		else if (parameter3.value === 'OME') { parameter3_val = 206; }
		else if (parameter3.value === 'ONT') { parameter3_val = 207; }
		else if (parameter3.value === 'ORD') { parameter3_val = 208; }
		else if (parameter3.value === 'ORF') { parameter3_val = 209; }
		else if (parameter3.value === 'OTH') { parameter3_val = 210; }
		else if (parameter3.value === 'OTZ') { parameter3_val = 211; }
		else if (parameter3.value === 'PAH') { parameter3_val = 212; }
		else if (parameter3.value === 'PBI') { parameter3_val = 213; }
		else if (parameter3.value === 'PDX') { parameter3_val = 214; }
		else if (parameter3.value === 'PHF') { parameter3_val = 215; }
		else if (parameter3.value === 'PHL') { parameter3_val = 216; }
		else if (parameter3.value === 'PHX') { parameter3_val = 217; }
		else if (parameter3.value === 'PIA') { parameter3_val = 218; }
		else if (parameter3.value === 'PIE') { parameter3_val = 219; }
		else if (parameter3.value === 'PIH') { parameter3_val = 220; }
		else if (parameter3.value === 'PIT') { parameter3_val = 221; }
		else if (parameter3.value === 'PLN') { parameter3_val = 222; }
		else if (parameter3.value === 'PNS') { parameter3_val = 223; }
		else if (parameter3.value === 'PSC') { parameter3_val = 224; }
		else if (parameter3.value === 'PSE') { parameter3_val = 225; }
		else if (parameter3.value === 'PSG') { parameter3_val = 226; }
		else if (parameter3.value === 'PSP') { parameter3_val = 227; }
		else if (parameter3.value === 'PVD') { parameter3_val = 228; }
		else if (parameter3.value === 'PWM') { parameter3_val = 229; }
		else if (parameter3.value === 'RAP') { parameter3_val = 230; }
		else if (parameter3.value === 'RDD') { parameter3_val = 231; }
		else if (parameter3.value === 'RDM') { parameter3_val = 232; }
		else if (parameter3.value === 'RDU') { parameter3_val = 233; }
		else if (parameter3.value === 'RIC') { parameter3_val = 234; }
		else if (parameter3.value === 'RKS') { parameter3_val = 235; }
		else if (parameter3.value === 'RNO') { parameter3_val = 236; }
		else if (parameter3.value === 'ROA') { parameter3_val = 237; }
		else if (parameter3.value === 'ROC') { parameter3_val = 238; }
		else if (parameter3.value === 'ROW') { parameter3_val = 239; }
		else if (parameter3.value === 'RST') { parameter3_val = 240; }
		else if (parameter3.value === 'RSW') { parameter3_val = 241; }
		else if (parameter3.value === 'SAF') { parameter3_val = 242; }
		else if (parameter3.value === 'SAN') { parameter3_val = 243; }
		else if (parameter3.value === 'SAT') { parameter3_val = 244; }
		else if (parameter3.value === 'SAV') { parameter3_val = 245; }
		else if (parameter3.value === 'SBA') { parameter3_val = 246; }
		else if (parameter3.value === 'SBN') { parameter3_val = 247; }
		else if (parameter3.value === 'SBP') { parameter3_val = 248; }
		else if (parameter3.value === 'SCC') { parameter3_val = 249; }
		else if (parameter3.value === 'SCE') { parameter3_val = 250; }
		else if (parameter3.value === 'SDF') { parameter3_val = 251; }
		else if (parameter3.value === 'SEA') { parameter3_val = 252; }
		else if (parameter3.value === 'SFO') { parameter3_val = 253; }
		else if (parameter3.value === 'SGF') { parameter3_val = 254; }
		else if (parameter3.value === 'SGU') { parameter3_val = 255; }
		else if (parameter3.value === 'SHV') { parameter3_val = 256; }
		else if (parameter3.value === 'SIT') { parameter3_val = 257; }
		else if (parameter3.value === 'SJC') { parameter3_val = 258; }
		else if (parameter3.value === 'SJT') { parameter3_val = 259; }
		else if (parameter3.value === 'SJU') { parameter3_val = 260; }
		else if (parameter3.value === 'SLC') { parameter3_val = 261; }
		else if (parameter3.value === 'SMF') { parameter3_val = 262; }
		else if (parameter3.value === 'SMX') { parameter3_val = 263; }
		else if (parameter3.value === 'SNA') { parameter3_val = 264; }
		else if (parameter3.value === 'SPI') { parameter3_val = 265; }
		else if (parameter3.value === 'SPS') { parameter3_val = 266; }
		else if (parameter3.value === 'SRQ') { parameter3_val = 267; }
		else if (parameter3.value === 'STL') { parameter3_val = 268; }
		else if (parameter3.value === 'STT') { parameter3_val = 269; }
		else if (parameter3.value === 'STX') { parameter3_val = 270; }
		else if (parameter3.value === 'SUN') { parameter3_val = 271; }
		else if (parameter3.value === 'SWF') { parameter3_val = 272; }
		else if (parameter3.value === 'SYR') { parameter3_val = 273; }
		else if (parameter3.value === 'TEX') { parameter3_val = 274; }
		else if (parameter3.value === 'TLH') { parameter3_val = 275; }
		else if (parameter3.value === 'TOL') { parameter3_val = 276; }
		else if (parameter3.value === 'TPA') { parameter3_val = 277; }
		else if (parameter3.value === 'TRI') { parameter3_val = 278; }
		else if (parameter3.value === 'TUL') { parameter3_val = 279; }
		else if (parameter3.value === 'TUS') { parameter3_val = 280; }
		else if (parameter3.value === 'TVC') { parameter3_val = 281; }
		else if (parameter3.value === 'TWF') { parameter3_val = 282; }
		else if (parameter3.value === 'TXK') { parameter3_val = 283; }
		else if (parameter3.value === 'TYR') { parameter3_val = 284; }
		else if (parameter3.value === 'TYS') { parameter3_val = 285; }
		else if (parameter3.value === 'UTM') { parameter3_val = 286; }
		else if (parameter3.value === 'VLD') { parameter3_val = 287; }
		else if (parameter3.value === 'VPS') { parameter3_val = 288; }
		else if (parameter3.value === 'WRG') { parameter3_val = 289; }
		else if (parameter3.value === 'XNA') { parameter3_val = 290; }
		else if (parameter3.value === 'YAK') { parameter3_val = 291; }
		else if (parameter3.value === 'YUM') { parameter3_val = 292; }
		formData.append("parameter3", parameter3_val);
		var parameter4_val = -1;
		if (parameter4.value === 'Saturday' || parameter4.value === 'Sunday') {
			parameter4_val = 0;
		} else if (parameter4.value === 'Monday' || parameter4.value === 'Tuesday' || parameter4.value === 'Wednesday' || parameter4.value === 'Thursday' || parameter4.value === 'Friday') {
			parameter4_val = 1;
		}
		formData.append("parameter4", parameter4_val);
		formData.append("parameter5", parameter5);
		formData.append("parameter6", parameter6);
		console.log("formData(ImmutableMultiDict): - parameter1", formData.get("parameter1"));
		console.log("formData(ImmutableMultiDict): - parameter2", formData.get("parameter2"));
		console.log("formData(ImmutableMultiDict): - parameter3", formData.get("parameter3"));
		console.log("formData(ImmutableMultiDict): - parameter4", formData.get("parameter4"));
		console.log("formData(ImmutableMultiDict): - parameter5", formData.get("parameter5"));
		console.log("formData(ImmutableMultiDict): - parameter6", formData.get("parameter6"));
		fetch("/predict",
			{
				method: "POST",
				body: formData
				// headers: {
				//     "Accept": "application/json",
				//     "Content-Type": "application/json"
				// },
				// body: JSON.stringify(formData)
			}
		).then(
			response => response.json()
		).then(
			result => {
				if (result.result === 'The flight will be on time') {
					Swal.fire({
						title: result.result,
						text: result.status,
						icon: 'success',
						confirmButtonText: 'Got it'
					})
				} else if (result.result === 'The flight will be delayed') {
					Swal.fire({
						title: result.result,
						text: result.status,
						icon: 'warning',
						confirmButtonText: 'Got it'
					})
				} else {
					Swal.fire({
						title: result.result,
						text: result.status,
						icon: 'error',
						confirmButtonText: 'Got it'
					})
				}
				console.log(result);
				setPredictval(result);
			}
		)
	}

	const reset = () => {
		setParameter1("");
		setParameter2("");
		setParameter3("");
		setParameter4("");
		setParameter5("");
		setParameter6("");
		setPredictval("");
	}

	// demo fetch data from flask backend
	// useEffect(() => {
	//     fetch("/demo").then(
	//         response => response.json()
	//     ).then(
	//         parameters => {
	//             setParameters(parameters);
	//             console.log("receive 3 paramaters: ", parameters);
	//         }
	//     )
	// }, [])

	return (
		<div>
			{/* <div>
				<form>
					<input name="parameter1" value={parameter1} placeholder="parameter1" onChange={(event) => set_parameter1(event.target.value)}></input>
					<input name="parameter2" value={parameter2} placeholder="parameter2" onChange={(event) => set_parameter2(event.target.value)}></input>
					<input name="parameter3" value={parameter3} placeholder="parameter3" onChange={(event) => set_parameter3(event.target.value)}></input>
					<input name="parameter4" value={parameter4} placeholder="parameter4" onChange={(event) => set_parameter4(event.target.value)}></input>
					<input name="parameter5" value={parameter5} placeholder="parameter5" onChange={(event) => set_parameter5(event.target.value)}></input>
					<input name="parameter6" value={parameter6} placeholder="parameter6" onChange={(event) => set_parameter6(event.target.value)}></input>
					<button id="submit" type="button" onClick={() => predict()}>Predict</button>
					<button id="reset" type="button" onClick={() => reset()}>Reset</button>
				</form>
				<p>Prediction Result: {predictval.result}</p>
			</div> */}
			{/* demo fetch data from flask backend */}
			{/* <div>
				{(typeof parameters.members === 'undefined') ?
					(
						<p>Loading...</p>
					) : (
						parameters.members.map((member, i) => (
							<p key={i}>{member}</p>
						))
					)}
			</div> */}
			<div className="relative">
				<div className="bg-cover bg-[url('./assets/background.png')]" >
					<header className="border-current border-gray-200 h-18">
						<div className="container mx-auto flex justify-between items-center py-4">
							<button
								onClick={() => window.location.href = "https://hku.hk"}
							>
								<img src={[require("./assets/hku-logo.png")]} alt="hku-logo" className="h-8" />
							</button>
						</div>
					</header>
					<div className="flex flex-col items-center w-full h-[calc(100vh-64px)]">
						<div className="h-[calc(100vh)]  w-full items-center flex justify-center">

							{/* </div>
						<div className="h-[calc(100vh)] w-full flex justify-center bg-yellow-400"> */}
							<div className="w-3/5 h-5/6 justify-center">
								<p className="text-center items-center h-14 font-black text-5xl text-white mb-5">Airline Flight Delay Predictor</p>
								<form className="w-full bg-blue-300 justify-center">
									<h2 className="w-1/2 float-left text-2xl text-center h-10 mb-5 font-black text-white">Airline:</h2>
									<div className='w-1/3 h-10 float-left mb-5'>
										<Select
											className="w-1/2 mx-auto"
											required="required"
											primaryColor={"emerald"}
											placeholder='Please select...'
											isSearchable="True"
											value={parameter1}
											onChange={set_parameter1}
											options={options1}
										/>
									</div>
									<h2 className="w-1/2 float-left text-2xl text-center h-10 mb-5 font-black text-white">Flight From:</h2>
									<div className='w-1/3 h-10 float-left mb-5'>
										<Select
											className="w-1/2 mx-auto"
											required="required"
											primaryColor={"emerald"}
											placeholder='Please select...'
											isSearchable="True"
											value={parameter2}
											onChange={set_parameter2}
											options={options2}
										/>
									</div>
									<h2 className="w-1/2 float-left text-2xl text-center h-10 mb-5 font-black text-white">Fight To:</h2>
									<div className='w-1/3 h-10 float-left mb-5'>
										<Select
											className="w-1/2 mx-auto"
											required="required"
											primaryColor={"emerald"}
											placeholder='Please select...'
											isSearchable="True"
											value={parameter3}
											onChange={set_parameter3}
											options={options2}
										/>
									</div>
									<h2 className="w-1/2 float-left text-2xl text-center h-10 mb-5 font-black text-white">Day of Week:</h2>
									<div className='w-1/3 h-10 float-left mb-5'>
										<Select
											className="w-1/2 mx-auto"
											required="required"
											primaryColor={"emerald"}
											placeholder='Please select...'
											value={parameter4}
											onChange={set_parameter4}
											options={options3}
										/>
									</div>
									<h2 className="w-1/2 float-left text-2xl text-center h-10 mb-5 font-black text-white">Flight Time:</h2>
									<div className='w-1/3 h-10 float-left mb-5'>
										<input
											className='bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:border-blue-500 focus:ring-blue-500  block w-full p-2.5 '
											type='number'
											required='required'
											placeholder='Please input...'
											value={parameter5}
											onChange={(event) => set_parameter5(event.target.value)}
										></input>
									</div>
									<h2 className="w-1/2 float-left text-2xl text-center h-10 mb-5 font-black text-white">Flight Length:</h2>
									<div className='w-1/3 h-10 float-left mb-5'>
										<input
											className='bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded focus:border-blue-500 focus:ring-blue-500  block w-full p-2.5 '
											type='number'
											required='required'
											placeholder='Please input...'
											value={parameter6}
											onChange={(event) => set_parameter6(event.target.value)}
										></input>
									</div>
								</form>
								<button className="w-full float-right bg-opacity-75 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
									onClick={() => predict()}
								>
									Predict
								</button>
								<button className="w-full bg-opacity-75 bg-pink-500 hover:bg-pink-600 text-white font-bold py-2 px-4 rounded"
									onClick={() => reset()}
								>
									Reset
								</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}

export default App;
